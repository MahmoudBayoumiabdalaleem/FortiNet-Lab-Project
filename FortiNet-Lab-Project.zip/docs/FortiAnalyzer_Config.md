
config log setting
    set status enable
    set logtraffic all
    set fortianalyzer enable
    set fortianalyzer-settings
        set server "10.0.1.210"
        set status enable
    end
end
